#!/bin/bash
for run in {1..10}
do
./experiment --buffer_size 1024 --file_name test.txt --write_count 2097152 >> 1.txt && sync;

./experiment --buffer_size 1024 --file_name test.txt --read_count 2097152 >> r1.txt && sync;

./experiment --buffer_size 4096 --file_name test.txt --write_count 524288 >> 2.txt && sync;

./experiment --buffer_size 4096 --file_name test.txt --read_count 524288 >> r2.txt && sync;

./experiment --buffer_size 32768 --file_name test.txt --write_count 65536 >> 3.txt && sync;

./experiment --buffer_size 32768 --file_name test.txt --read_count 65536 >> r3.txt && sync;

./experiment --buffer_size 65536 --file_name test.txt --write_count 32786 >> 4.txt && sync;

./experiment --buffer_size 65536 --file_name test.txt --read_count 32786 >> r4.txt && sync;

./experiment --buffer_size 131072 --file_name test.txt --write_count 16393 >> 5.txt && sync;

./experiment --buffer_size 131072 --file_name test.txt --read_count 16393 >> r5.txt && sync;

./experiment --buffer_size 524288 --file_name test.txt --write_count 4096 >> 6.txt && sync;

./experiment --buffer_size 524288 --file_name test.txt --read_count 4096 >> r6.txt && sync;

./experiment --buffer_size 1048576 --file_name test.txt --write_count 2048 >> 7.txt && sync;

./experiment --buffer_size 1048576 --file_name test.txt --read_count 2048 >> r7.txt && sync;
done
