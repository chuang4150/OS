#include "DefaultClock.h"
#include <iostream>
#include <cstring>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#define READ_SYSTEM_CALL 0
#define WRITE_SYSTEM_CALL 1
#define OPEN_SYSTEM_CALL 2
#define CLOSE_SYSTEM_CALL 3

using AccurateClock::DefaultClock;
using std::cout;
using std::endl;

size_t my_write(int fd, const void *buffer, size_t nbytes) {
	ssize_t returnValue;
		returnValue = syscall(WRITE_SYSTEM_CALL, fd, buffer, nbytes);
                	return returnValue;
};

size_t my_read(int fd, void *buffer, size_t nbytes) {
	ssize_t returnValue;
		returnValue = syscall(READ_SYSTEM_CALL, fd, buffer, nbytes);
			return returnValue;
};


int my_open(const char *filename, int flag, mode_t mode){
          int returnValue;
              returnValue = syscall(OPEN_SYSTEM_CALL, filename, flag, mode);
                        return returnValue;
};


int my_close(const char *filename, int flag, mode_t mode){
          int returnValue;
              returnValue = syscall(CLOSE_SYSTEM_CALL, filename, flag, mode);
                        return returnValue;
};

int main(int argc, char *argv[]) {

long buffer_size;
char * file_name;
long write_count;
long read_count;

if(argc != 7){
	return 0;
}

for (int i = 1 ;i < argc - 1; i++){
	if(strcmp(argv[i], "--buffer_size") == 0){
		buffer_size = atoi(argv[i+1]);
	}

	else if(strcmp(argv[i],"--file_name") == 0){
		file_name = argv[i+1];
	}
	else if(strcmp(argv[i],"--write_count") == 0){
		write_count = atoi(argv[i+1]);
	}
	else if(strcmp(argv[i],"--read_count") == 0){
		read_count = atoi(argv[i+1]);
	}
}

      auto clock = DefaultClock();
      char BuffChar[buffer_size];
      long myDirectory;
     
    for (int i = 1; i < argc -1; i++){
      if(strcmp(argv[i],"--write_count") == 0){
      myDirectory = my_open(file_name,O_RDWR|O_CREAT|O_TRUNC,0666);
      long timesToWrite = (write_count);
      auto start = clock.getTime();
      long bytesWrote = 0;
	   for(int i = 0; i < timesToWrite; i++)
      {
         
	      bytesWrote = bytesWrote + my_write(myDirectory, BuffChar, buffer_size);
      }
      

      auto end = clock.getTime();
      auto duration = (end - start);
     // double end = (duration/10000);
      cout << "Wrote a total of ";
      printf("%ld bytes", bytesWrote);
      cout << endl;

      duration.print(cout << "Program finished in ");
      cout << endl;

      close(myDirectory);
      
      }
      
      else if(strcmp(argv[i],"--read_count") == 0) {
      myDirectory = my_open(file_name,O_RDWR|O_CREAT,0777);
      long timesToRead = (read_count);
      auto start = clock.getTime();
      long bytesRead = 0;
	   for(int i = 0; i < timesToRead; i++)
      {
              bytesRead = bytesRead + my_read(myDirectory, BuffChar, buffer_size);
      }

      auto end = clock.getTime();
      auto duration =(end - start);
     // double end = (duration/10000);
      cout << "Read a total of  ";
      printf("%ld bytes", bytesRead);
      cout << endl;

      duration.print(cout << "Program finished in ");
      cout << endl;
      
      close(myDirectory);

      }
    
    }
    return 0;
}
